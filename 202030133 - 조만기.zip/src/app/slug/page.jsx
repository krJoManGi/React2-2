export default function slug() {
    return (
        <h1>src/app/slug/page.jsx</h1>
    )
}