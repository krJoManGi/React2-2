export default function contact() {
    return (
        <h1>src/app/Contact/page.jsx</h1>
    )
}