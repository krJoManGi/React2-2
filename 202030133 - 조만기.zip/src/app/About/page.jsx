export default function about() {
    return (
        <h1>src/app/About/page.jsx</h1>
    )
}